def enable_vmd(client):
    """Enable VMD enumeration."""
    return client.call('enable_vmd')
